#include <stdio.h>
#include <tk.h>
int main (){
	puts(TK_VERSION);
	return 0;
}
